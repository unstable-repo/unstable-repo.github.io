/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.redis.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.RedisScript;

import java.util.Collections;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @author tomoncle
 */
public class DistributedLock {

    // 定义 ThreadLocal 存储当前线程的加锁凭据
    private static final ThreadLocal<String> localCertificates = new ThreadLocal<>();
    private final StringRedisTemplate redisTemplate;
    private Logger logger = LoggerFactory.getLogger(DistributedLock.class);

    public DistributedLock(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /**
     * 阻塞锁，加分布式锁
     *
     * @param key               key
     * @param certificate       加锁对象，凭证
     * @param expireTimeSeconds 超时时间
     * @return Boolean
     */
    public Boolean lock(String key, String certificate, int expireTimeSeconds) {
        Boolean value = this.redisTemplate.opsForValue().setIfAbsent(key, certificate, expireTimeSeconds, TimeUnit.SECONDS);
        while (Objects.isNull(value) || !value) {
            value = this.redisTemplate.opsForValue().setIfAbsent(key, certificate, expireTimeSeconds, TimeUnit.SECONDS);
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        logger.debug("加锁：[ key：" + key + " ，凭据：" + certificate + " ]：OK");
        return true;

    }

    /**
     * 阻塞锁，加分布式锁, 自动维护凭据
     *
     * @param key               key
     * @param expireTimeSeconds 超时时间
     * @return Boolean
     */
    public Boolean lock(String key, int expireTimeSeconds) {
        String certificate = UUID.randomUUID().toString().replaceAll("-", "");
        localCertificates.set(certificate);
        return lock(key, certificate, expireTimeSeconds);
    }

    /**
     * 非阻塞锁，加分布式锁
     *
     * @param key               key
     * @param certificate       加锁对象，凭证
     * @param expireTimeSeconds 超时时间
     * @return Boolean
     */
    public Boolean unBlockLock(String key, String certificate, int expireTimeSeconds) {
        Boolean value = this.redisTemplate.opsForValue().setIfAbsent(key, certificate, expireTimeSeconds, TimeUnit.SECONDS);
        logger.debug("加锁：[ key：" + key + " ，凭据：" + certificate + " ]: " + value);
        return value;

    }

    /**
     * 删除分布式锁
     *
     * @param key         key
     * @param certificate 解锁对象，凭证
     * @return Boolean
     */
    public Boolean unlock(String key, String certificate) {
        String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
        Object value = redisTemplate.execute(RedisScript.of(script, Long.class), Collections.singletonList(key), certificate);
        logger.debug("解锁：[ key：" + key + " ，凭据：" + certificate + " ]: " + value);
        if (Objects.isNull(value)) {
            return true;
        }
        return Objects.equals("1", value.toString());

    }

    /**
     * 删除分布式锁, 自动维护凭据
     *
     * @param key key
     * @return Boolean
     */
    public Boolean unlock(String key) {
        String certificate = localCertificates.get();
        localCertificates.remove();
        return unlock(key, certificate);
    }

}
