/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.redis;

import com.tomoncle.config.springboot.redis.tools.DistributedLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.util.Assert;
import redis.clients.jedis.JedisPoolConfig;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;


@Configuration
@ConditionalOnProperty(value = {"spring.boot.config.redis.enable"}, havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties({RedisProperties.class, SpringbootConfigRedisProperties.class})
public class SpringbootConfigRedisConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(SpringbootConfigRedisConfiguration.class);

    private final RedisProperties redisProperties;

    public SpringbootConfigRedisConfiguration(RedisProperties rp1, SpringbootConfigRedisProperties rp2) {
        logger.info("Initializing RedisConfiguration, load configuration [{}] mode.", rp2.getMode());
        this.redisProperties = rp1;
    }

    /**
     * 单机模式
     *
     * @return RedisStandaloneConfiguration
     */
    @Bean
    @ConditionalOnProperty(value = {"spring.boot.config.redis.mode"}, havingValue = "standalone", matchIfMissing = true)
    public RedisStandaloneConfiguration redisStandaloneConfiguration() {
        logger.debug("Initializing RedisStandaloneConfiguration.");
        RedisStandaloneConfiguration standaloneConfiguration = new RedisStandaloneConfiguration();
        standaloneConfiguration.setDatabase(redisProperties.getDatabase());
        standaloneConfiguration.setHostName(redisProperties.getHost());
        if (null != redisProperties.getPassword() && redisProperties.getPassword().length() > 0) {
            standaloneConfiguration.setPassword(redisProperties.getPassword());
        }
        standaloneConfiguration.setPort(redisProperties.getPort());
        return standaloneConfiguration;
    }

    /**
     * 集群模式时加载
     *
     * @return RedisClusterConfiguration
     */
    @Bean
    @ConditionalOnProperty(value = {"spring.boot.config.redis.mode"}, havingValue = "cluster")
    public RedisClusterConfiguration redisClusterConfiguration() {
        logger.debug("Initializing RedisClusterConfiguration.");
        Assert.isTrue(null != redisProperties.getCluster().getNodes(),
                "initializing RedisClusterConfiguration error, spring.redis.cluster.nodes cannot be null.");
        RedisClusterConfiguration clusterConfiguration = new RedisClusterConfiguration();
        List<RedisNode> redisNodeList = new ArrayList<>();
        for (String node : redisProperties.getCluster().getNodes()) {
            String[] nodeChart = node.split(":");
            redisNodeList.add(new RedisNode(nodeChart[0], Integer.valueOf(nodeChart[1])));
        }
        clusterConfiguration.setClusterNodes(redisNodeList);
        if (null != redisProperties.getCluster().getMaxRedirects() && redisProperties.getCluster().getMaxRedirects() >= 0) {
            clusterConfiguration.setMaxRedirects(redisProperties.getCluster().getMaxRedirects());
        }
        if (null != redisProperties.getPassword() && redisProperties.getPassword().length() > 0) {
            clusterConfiguration.setPassword(redisProperties.getPassword());
        }
        return clusterConfiguration;
    }

    @Bean
    @ConditionalOnMissingBean(name = "jedisPoolConfig")
    public JedisPoolConfig jedisPoolConfig() {
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        RedisProperties.Pool pool = redisProperties.getJedis().getPool();
        if (null == pool) {
            pool = new RedisProperties.Pool();
        }
        jedisPoolConfig.setMaxIdle(pool.getMaxIdle());
        jedisPoolConfig.setMinIdle(pool.getMinIdle());
        jedisPoolConfig.setMaxTotal(pool.getMaxActive());
        jedisPoolConfig.setMaxWaitMillis(pool.getMaxWait().toMillis());
        jedisPoolConfig.setTestWhileIdle(true);
        jedisPoolConfig.setTestOnBorrow(true);
        jedisPoolConfig.setTestOnReturn(false);
        return jedisPoolConfig;
    }

    @Bean
    @ConditionalOnMissingBean(name = "jedisClientConfiguration")
    public JedisClientConfiguration jedisClientConfiguration(JedisPoolConfig jedisPoolConfig) {
        final Duration timeout = null == redisProperties.getTimeout() ? Duration.ofMinutes(10) : redisProperties.getTimeout();
        return JedisClientConfiguration.builder()
                .usePooling().poolConfig(jedisPoolConfig)
                .and()
                .readTimeout(timeout)
                .connectTimeout(timeout)
                .build();
    }

    /**
     * 单机模式采用该bean
     *
     * @param redisStandaloneConfiguration 单机配置
     * @return RedisConnectionFactory
     */
    @Bean
    @ConditionalOnProperty(value = {"spring.boot.config.redis.mode"}, havingValue = "standalone", matchIfMissing = true)
    public RedisConnectionFactory redisConnectionFactory(RedisStandaloneConfiguration redisStandaloneConfiguration,
                                                         JedisClientConfiguration jedisClientConfiguration) {
        logger.debug("Initializing RedisConnectionFactory From Configuration [standalone] mode.");
        return new JedisConnectionFactory(redisStandaloneConfiguration, jedisClientConfiguration);
    }

    /**
     * 使用集群模式时，加载该bean
     *
     * @param redisClusterConfiguration 集群配置
     * @return RedisConnectionFactory
     */
    @Bean
    @ConditionalOnProperty(value = {"spring.boot.config.redis.mode"}, havingValue = "cluster")
    public RedisConnectionFactory redisConnectionFactory(RedisClusterConfiguration redisClusterConfiguration,
                                                         JedisPoolConfig jedisPoolConfig) {
        logger.debug("Initializing RedisConnectionFactory From Configuration [cluster] mode.");
        return new JedisConnectionFactory(redisClusterConfiguration, jedisPoolConfig);
    }


    /**
     * 已经注册的bean 见该文件
     * org\springframework\boot\spring-boot-autoconfigure\2.1.2.RELEASE\spring-boot-autoconfigure-2.1.2.RELEASE.jar
     *
     * @param redisConnectionFactory RedisConnectionFactory bean
     * @return RedisTemplate
     * @see org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration
     */
    @Bean
    @ConditionalOnMissingBean(name = "redisTemplate")
    public RedisTemplate<Object, Object> redisTemplate(
            @Qualifier("redisConnectionFactory") RedisConnectionFactory redisConnectionFactory) {
        logger.debug("Initializing RedisTemplate.");
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        redisTemplate.setEnableTransactionSupport(false);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        return redisTemplate;
    }

    @Bean
    @ConditionalOnMissingBean(name = "stringRedisTemplate")
    public StringRedisTemplate stringRedisTemplate(
            @Qualifier("redisConnectionFactory") RedisConnectionFactory redisConnectionFactory) {
        logger.debug("Initializing StringRedisTemplate.");
        StringRedisTemplate template = new StringRedisTemplate();
        template.setEnableTransactionSupport(false);
        template.setConnectionFactory(redisConnectionFactory);
        return template;
    }

    /**
     * 配置分布式锁对象
     *
     * @param stringRedisTemplate StringRedisTemplate
     * @return DistributedLock
     */
    @Bean
    public DistributedLock distributedLock(StringRedisTemplate stringRedisTemplate) {
        return new DistributedLock(stringRedisTemplate);
    }


}
