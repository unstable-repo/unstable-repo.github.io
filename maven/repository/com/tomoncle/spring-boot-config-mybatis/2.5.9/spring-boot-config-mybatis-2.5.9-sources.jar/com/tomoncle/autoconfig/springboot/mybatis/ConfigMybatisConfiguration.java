/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.Ordered;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Objects;


//    /*
//     * Mybatis Bean扫描配置  @see {@link ConfigMapperScanner#mapperScannerConfigurer}
//     * <p>
//     * <p>
//     * Mybatis会自动查找指定包下的Dao接口，使其自动注入
//     * 若不配置该属性，默认使用 {@link org.apache.ibatis.annotations.Mapper} 注解可实现自动注入
//     * mapperScannerConfigurer.setBasePackage(this.applicationContext.getEnvironment().getProperty(MYBATIS_CONFIG_BASE_PACKAGE));
//     * <p>
//     * 扫描使用该注解的类
//     * mapperScannerConfigurer.setAnnotationClass(MyBatisRepository.class);
//     * <p>
//     * 扫描实现该接口的类
//     * mapperScannerConfigurer.setMarkerInterface(MybatisBaseMapper.class);
//     * <p>
//     * ** 注意：3种配置只能使用一种
//     * <p>
//     * <p/>
//     * 引用sqlSessionFactory，防止提前初始化sqlSessionFactory，配置参数的属性为空（jdbc.properties未加载），
//     * 所以推荐使用sqlSessionFactoryBeanName 后处理的方式，
//     * 在其使用该bean时，才会初始化，不推荐使用sqlSessionFactory
//     *
//     * @return MapperScannerConfigurer
//     */
//    @Bean
//    @ConditionalOnProperty(value = {"spring.boot.config.mybatis.scannerType"}, havingValue = "packages", matchIfMissing = true)
//    public MapperScannerConfigurer mapperScannerConfigurer() {
//        logger.info("init mapperScannerConfigurer for packages.");
//        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
//        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactoryBean");
//        // Mybatis会自动查找指定包下的Dao接口，使其自动注入; 默认使用org.apache.ibatis.annotations.Mapper注解自动注入
//        mapperScannerConfigurer.setBasePackage(configMybatisProperties.getConfig().getBasePackage());
//        return mapperScannerConfigurer;
//    }
//
//    /*
//     * Mybatis Bean扫描配置  @see {@link ConfigMapperScanner#mapperScannerConfigurer}
//     * 使用注解的方式扫描Dao接口
//     * @return MapperScannerConfigurer
//     */
//    @Bean
//    @ConditionalOnProperty(value = {"spring.boot.config.mybatis.scannerType"}, havingValue = "annotations")
//    public MapperScannerConfigurer mapperScannerConfigurerForAnnotation() {
//        logger.info("init mapperScannerConfigurer for annotations.");
//        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
//        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactoryBean");
//        // 扫描使用该注解的类, 自动注入
//        mapperScannerConfigurer.setAnnotationClass(MyBatisRepository.class);
//        return mapperScannerConfigurer;
//    }
//
//    /*
//     * Mybatis Bean扫描配置  @see {@link ConfigMapperScanner#mapperScannerConfigurer}
//     * 使用公共接口的方式扫描Dao接口
//     * @return MapperScannerConfigurer
//     */
//    @Bean
//    @ConditionalOnProperty(value = {"spring.boot.config.mybatis.scannerType"}, havingValue = "interfaces")
//    public MapperScannerConfigurer mapperScannerConfigurerForInterface() {
//        logger.info("init mapperScannerConfigurer for interfaces.");
//        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
//        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactoryBean");
//        // 扫描实现该接口的类，自动注入
//        mapperScannerConfigurer.setMarkerInterface(MybatisBaseMapper.class);
//        return mapperScannerConfigurer;
//    }

/**
 * Mybatis 自动配置
 *
 * @author tomoncle
 */
@AutoConfigureOrder(Ordered.HIGHEST_PRECEDENCE)
@Configuration
@EnableTransactionManagement(proxyTargetClass = true)
@EnableConfigurationProperties(ConfigMybatisProperties.class)
@ConditionalOnSingleCandidate(DataSource.class)
@AutoConfigureAfter(DataSourceAutoConfiguration.class)
@AutoConfigureBefore(ConfigMapperScanner.class)
public class ConfigMybatisConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(ConfigMybatisConfiguration.class);

    private final ConfigMybatisProperties configMybatisProperties;

    public ConfigMybatisConfiguration(ConfigMybatisProperties configMybatisProperties) {
        logger.debug("init ConfigMybatisConfiguration");
        logger.debug("load ConfigMybatisProperties : {}", configMybatisProperties);
        this.configMybatisProperties = configMybatisProperties;
    }

    /**
     * 配置sqlSessionFactory
     */
    @Primary // 使用该注解解决同一类型bean注入问题
    @Bean
    public SqlSessionFactoryBean sqlSessionFactoryBean(DataSource dataSource) throws IOException {
        logger.debug("init SqlSessionFactoryBean");
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(dataSource);

        //扫描实体类包，使用别名  value="entity;entity2"
        sqlSessionFactoryBean.setTypeAliasesPackage(configMybatisProperties.getConfig().getTypeAliasesPackage());
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        // mybatis configuration 配置文件中配置示例:mybatis.config.configLocation=/config/mybatis.xml
        if (!Objects.isNull(configMybatisProperties.getConfig().getConfigLocation())) {
            sqlSessionFactoryBean.setConfigLocation(resolver.getResource(
                    "classpath:" + configMybatisProperties.getConfig().getConfigLocation()));
        }

        //自动扫描mapping.xml文件,value="classpath:mapper/*.xml"
        Resource[] resources = resolver.getResources(
                "classpath:" + configMybatisProperties.getConfig().getMapperLocations());
        sqlSessionFactoryBean.setMapperLocations(resources);
        return sqlSessionFactoryBean;
    }

    /**
     * 绑定事务到数据源，
     *
     * @param dataSource 数据源
     */
    @Bean
    public DataSourceTransactionManager transactionManager(DataSource dataSource) {
        logger.debug("init DataSourceTransactionManager");
        return new DataSourceTransactionManager(dataSource);
    }


    @Bean
    @ConditionalOnProperty(value = {"spring.boot.config.mybatis.dataSource"}, havingValue = "error")
    public DataSource dataSource() {
        throw new RuntimeException("cannot find Datasource Bean.");
    }

}
