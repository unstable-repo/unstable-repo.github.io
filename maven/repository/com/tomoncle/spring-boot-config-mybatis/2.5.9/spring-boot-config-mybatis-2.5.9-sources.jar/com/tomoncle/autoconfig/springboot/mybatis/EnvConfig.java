/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * * 实现ApplicationContextAware为使用系统环境变量
 *
 * @author tomoncle
 */

@Deprecated
//@Configuration
public class EnvConfig implements ApplicationContextAware, Constants {
    private static final Logger LOGGER = LoggerFactory.getLogger(EnvConfig.class);
    //系统环境变量
    private ApplicationContext applicationContext;

    /**
     * 获取环境变量，包括 application.properties 配置文件的配置信息
     *
     * @param key key
     * @return value
     */
    public String getEnv(String key) {
        return applicationContext.getEnvironment().getProperty(key);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        LOGGER.info("加载 ApplicationContext ：" + applicationContext);
        LOGGER.info(applicationContext.getEnvironment().getProperty("spring.boot.config.mybatis.scannerType"));
        LOGGER.info(applicationContext.getEnvironment().getProperty(SYSTEM_LOCALE));
        this.applicationContext = applicationContext;
    }
}
