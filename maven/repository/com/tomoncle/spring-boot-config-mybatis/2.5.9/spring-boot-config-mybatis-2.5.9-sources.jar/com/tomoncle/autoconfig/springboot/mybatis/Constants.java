/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

/**
 * Mybatis常量
 * Created by tom.lee on 2017/12/2.
 */
@Deprecated
public interface Constants {
    // system config
    String SYSTEM_LOCALE = "system.locale";
    String SYSTEM_CLASSPATH_PREFIX = "classpath*:";
    String SYSTEM_PROPERTIES_NAME = "projectSystem.properties";
    String SYSTEM_PROPERTIES_LOCATION = "classpath*:projectSystem.properties";
    String CUSTOM_PROPERTIES_LOCATION_RULE = "classpath*:config/*.properties";

    // mybatis config
    String MYBATIS_CONFIG_TYPE_ALIASES_PACKAGE = "mybatis.config.typeAliasesPackage";
    String MYBATIS_CONFIG_SQL_TYPE = "mybatis.config.sqlType";
    String MYBATIS_CONFIG_BASE_PACKAGE = "mybatis.config.basePackage";
    String MYBATIS_CONFIG_MAPPER_LOCATIONS = "mybatis.config.mapperLocations";
    String MYBATIS_CONFIG_CONFIGURATION_LOCATION = "mybatis.config.configLocation";

    // druid config
    String DRUID_DATASOURCE_USERNAME = "druid.datasource.username";
    String DRUID_DATASOURCE_URL = "druid.datasource.url";
    String DRUID_DATASOURCE_PASSWORD = "druid.datasource.password";
    String DRUID_DATASOURCE_FILTERS = "druid.datasource.filters";
    String DRUID_DATASOURCE_MAXACTIVE = "druid.datasource.maxActive";
    String DRUID_DATASOURCE_INITIALSIZE = "druid.datasource.initialSize";
    String DRUID_DATASOURCE_MAXWAIT = "druid.datasource.maxWait";
    String DRUID_DATASOURCE_MINIDLE = "druid.datasource.minIdle";
    String DRUID_DATASOURCE_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "druid.datasource.timeBetweenEvictionRunsMillis";
    String DRUID_DATASOURCE_MIN_EVICTABLE_IDLE_TIME_MILLIS = "druid.datasource.minEvictableIdleTimeMillis";
    String DRUID_DATASOURCE_VALIDATION_QUERY = "druid.datasource.validationQuery";
    String DRUID_DATASOURCE_TEST_WHILE_IDLE = "druid.datasource.testWhileIdle";
    String DRUID_DATASOURCE_TEST_ON_BORROW = "druid.datasource.testOnBorrow";
    String DRUID_DATASOURCE_TEST_ON_RETURN = "druid.datasource.testOnReturn";
    String DRUID_DATASOURCE_POOL_PREPARED_STATEMENTS = "druid.datasource.poolPreparedStatements";
    String DRUID_DATASOURCE_MAX_OPEN_PREPARED_STATEMENTS = "druid.datasource.maxOpenPreparedStatements";
    String DRUID_DATASOURCE_SLOW_SQL_MILLIS = "druid.datasource.slowSqlMillis";
    String DRUID_DATASOURCE_IS_LOG_SLOW_SQL = "druid.datasource.isLogSlowSql";

    // http config
    String HTTP_CLIENT_SOCKET_TIME_OUT = "http.client.socketTimeout";
    String HTTP_CLIENT_CONNECTION_REQUEST_TIME_OUT = "http.client.connectionRequestTimeout";
    String HTTP_CLIENT_CONNECTION_TIME_OUT = "http.client.connectionTimeout";
    String HTTP_CLIENT_CLOSE_IDLE_CONNECTIONS = "http.client.closeIdleConnections";

    // spring config
    String EHCACHE_FILE = "ehcache.file";
    String MVC_MESSAGE_CACHE_SECONDS = "cacheSeconds";
    String MVC_MESSAGE_PATH = "path";
    String MVC_VIEW_ERROR = "error";
    String MVC_VIEW_PREFIX = "prefix";
    String MVC_VIEW_SUFFIX = "suffix";
}
