/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils.http;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.Buffer;
import okio.BufferedSink;
import okio.ForwardingSink;
import okio.Okio;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.DecimalFormat;

/**
 * <p>描述信息：自定义的 RequestBody，用于监控上传进度和计算上传速度
 *
 * <blockquote><pre>
 * // 创建文件
 * File file = new File("/Users/Downloads/CLion-2024.1.tar.gz");
 * // 创建请求体
 * RequestBody body = RequestBody.create(file, MediaType.parse("application/octet-stream"));
 * RequestBody requestBody = new MultipartBody.Builder()
 *         .setType(MultipartBody.FORM)
 *         .addFormDataPart("file", file.getName(), body)
 *         .build();
 * // 创建进度监听器
 * ProgressListener progressListener = new ProgressListener() {
 *     private long lastUpdateTime = System.currentTimeMillis();
 *     private long lastBytesWritten = 0L;
 *
 *     public void onProgressUpdate(long bytesWritten, long contentLength, boolean done) {
 *         // 进度计算
 *         float percentage = Float.parseFloat(String.valueOf(bytesWritten)) / contentLength;
 *         DecimalFormat df = new DecimalFormat("0.00%");
 *         String progress = df.format(percentage);
 *         // 计算上传速度
 *         long currentTime = System.currentTimeMillis();
 *         long timeElapsed = currentTime - lastUpdateTime;
 *         if (timeElapsed > 0) {
 *             long bytesUploaded = bytesWritten - lastBytesWritten;
 *             DecimalFormat dfs = new DecimalFormat("0.00 MB/s");
 *             float speedPerSec = (float) (bytesUploaded/1024.0/1024.0 / (timeElapsed / 1000.0)); // MB bytes per second
 *             String speed = dfs.format(speedPerSec);
 *             // 更新上次写入的字节数和时间
 *             lastBytesWritten = bytesWritten;
 *             lastUpdateTime = currentTime;
 *             // log
 *             logger.debug("上传进度: {}, 当前速度: {}", progress, speed);
 *         }
 *     }
 * };
 * // 构建请求
 * try (Response response = Requests.POST.response("http://127.0.0.1:5000/post", new ProgressRequestBody(body, progressListener));
 *      ResponseBody responseBody = response.body()) {
 *     System.out.println(Objects.requireNonNull(responseBody).string());
 * } catch (IOException e) {
 *     System.out.println(e.getMessage());
 * }
 * </pre></blockquote>
 *
 * @author tomoncle
 * @version 1.0.0
 * @apiNote 使用说明。
 * @since JDK1.8
 */
public class ProgressRequestBody extends RequestBody {
    private static final Logger logger = LoggerFactory.getLogger(ProgressRequestBody.class);
    private final RequestBody requestBody;
    private final ProgressListener listener;
    private final String logPrompt;

    public ProgressRequestBody(RequestBody requestBody, ProgressListener listener, String logPrompt) {
        this.requestBody = requestBody;
        this.listener = listener;
        this.logPrompt = getDefaultValue(logPrompt);
    }

    public ProgressRequestBody(RequestBody requestBody, ProgressListener listener) {
        this.requestBody = requestBody;
        this.listener = listener;
        this.logPrompt = getDefaultValue(null);
    }

    public ProgressRequestBody(RequestBody requestBody, String logPrompt) {
        this.logPrompt = getDefaultValue(logPrompt);
        this.requestBody = requestBody;
        this.listener = defaultProgressListener();
    }

    public ProgressRequestBody(RequestBody requestBody) {
        this.requestBody = requestBody;
        this.logPrompt = getDefaultValue(null);
        this.listener = (bytesWritten, contentLength, done, logPrompt) -> {
            float percentage = Float.parseFloat(String.valueOf(bytesWritten)) / contentLength;
            DecimalFormat df = new DecimalFormat("0.00%");
            String progress = df.format(percentage);
            logger.debug("上传进度: {}", progress);
            if (done) {
                logger.debug("上传完成!");
            }
        };
    }

    private ProgressListener defaultProgressListener() {
        return new ProgressListener() {
            private long lastUpdateTime = System.currentTimeMillis();
            private long lastBytesWritten = 0L;

            @Override
            public void onProgressUpdate(long bytesWritten, long contentLength, boolean done, String logPrompt) {
                // 进度计算
                float percentage = Float.parseFloat(String.valueOf(bytesWritten)) / contentLength;
                DecimalFormat df = new DecimalFormat("0.00%");
                String progress = df.format(percentage);
                // 速度计算
                long currentTime = System.currentTimeMillis();
                long timeElapsed = currentTime - lastUpdateTime;
                // 一秒输出一次，或者上传结束时输出，避免刷屏
                if (timeElapsed >= 1000 || done) {
                    long bytesUploaded = bytesWritten - lastBytesWritten;
                    DecimalFormat dfs = new DecimalFormat("0.00 MB/s");
                    // MB bytes per second
                    float speedPerSec = (float) (bytesUploaded / 1024.0 / 1024.0 / (timeElapsed / 1000.0));
                    String speed = dfs.format(speedPerSec);
                    // 更新上次写入的字节数和时间
                    lastBytesWritten = bytesWritten;
                    lastUpdateTime = currentTime;
                    // log
                    logger.debug("{}上传进度: {}, 当前速度: {}", logPrompt, progress, speed);
                }
                if (done) {
                    logger.debug("{}上传完成!", logPrompt);
                }
            }
        };
    }


    private String getDefaultValue(String val) {
        return StringUtils.hasText(val) ? val : "";
    }

    @Override
    public MediaType contentType() {
        return requestBody.contentType();
    }

    @Override
    public long contentLength() {
        try {
            return requestBody.contentLength();
        } catch (IOException e) {
            return -1;
        }
    }

    @Override
    public void writeTo(@NotNull BufferedSink sink) throws IOException {
        BufferedSink bufferedSink = Okio.buffer(new ForwardingSink(sink) {
            long bytesWritten = 0L;

            @Override
            public void write(@NotNull Buffer source, long byteCount) throws IOException {
                super.write(source, byteCount);
                bytesWritten += byteCount;
                listener.onProgressUpdate(bytesWritten, contentLength(), bytesWritten == contentLength(), logPrompt);
            }
        });
        requestBody.writeTo(bufferedSink);
        bufferedSink.flush();
    }
}

