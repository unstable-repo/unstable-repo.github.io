package com.tomoncle.config.springboot.utils.http;

/**
 * 定义一个接口，用于回调上传进度
 */
public interface ProgressListener {
    /**
     * 计算每秒的上传速度并打印进度和速度
     *
     * @param bytesWritten  写入字节数
     * @param contentLength 总字节数
     * @param done          是否完成
     * @param logPrompt     自定义的日志输出
     */
    void onProgressUpdate(long bytesWritten, long contentLength, boolean done, String logPrompt);
}
