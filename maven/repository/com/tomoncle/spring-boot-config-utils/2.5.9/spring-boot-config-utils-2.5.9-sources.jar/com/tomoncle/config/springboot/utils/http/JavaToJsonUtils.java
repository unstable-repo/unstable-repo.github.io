package com.tomoncle.config.springboot.utils.http;

import com.alibaba.fastjson.JSONObject;

public final class JavaToJsonUtils {

    /**
     * 将java对象转为json对象
     *
     * @param obj java对象
     * @return json对象
     * <p>
     * String[] array = {"java", "python", "golang"};
     * // ["java","python","golang"]
     * <p>
     * Map<String, String> map = new HashMap<String, String>(){{
     * put("name", "tom");
     * put("age", "23");
     * }};
     * // {"name":"tom","age":"23"}
     * <p>
     * System.out.println(toJson(map));
     * <p>
     * List<Object> list = new ArrayList<Object>() {{
     * add(array);
     * add(map);
     * }};
     * // [["java","python","golang"],{"name":"tom","age":"23"}]
     */
    public static String toJson(Object obj) {
        return JSONObject.toJSONString(obj);
    }
}
