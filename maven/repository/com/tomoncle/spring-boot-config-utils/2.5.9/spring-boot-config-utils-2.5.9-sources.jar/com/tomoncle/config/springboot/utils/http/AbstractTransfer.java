/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils.http;

import okhttp3.Headers;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import javax.annotation.Nullable;
import java.io.IOException;

abstract class AbstractTransfer extends AbstractBasic {
    public @Nullable String request(String url, SimpleRequestBody simpleRequestBody) throws IOException {
        try (Response response = this.response(url, simpleRequestBody); ResponseBody body = response.body()) {
            return body != null ? body.string() : "";
        }
    }

    public @Nullable String request(String url, SimpleRequestBody simpleRequestBody, Headers headers) throws IOException {
        try (Response response = this.response(url, simpleRequestBody, headers); ResponseBody body = response.body()) {
            return body != null ? body.string() : "";
        }
    }

    public Response response(String url, SimpleRequestBody simpleRequestBody, Headers headers) throws IOException {
        return method(url, simpleRequestBody, headers);
    }

    public Response response(String url, SimpleRequestBody simpleRequestBody) throws IOException {
        return response(url, simpleRequestBody, null);
    }

    public Response response(String url, RequestBody requestBody, Headers headers) throws IOException {
        return method(url, requestBody, headers);
    }

    public Response response(String url, RequestBody requestBody) throws IOException {
        return response(url, requestBody, null);
    }

    Response method(String url, SimpleRequestBody simpleRequestBody, Headers headers) throws IOException {
        return method(url, simpleRequestBody.toRequestBody(), headers);
    }

}