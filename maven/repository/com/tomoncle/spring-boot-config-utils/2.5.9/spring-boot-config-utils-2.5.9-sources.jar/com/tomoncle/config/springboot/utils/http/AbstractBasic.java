/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils.http;

import okhttp3.Headers;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import javax.annotation.Nullable;
import java.io.IOException;

abstract class AbstractBasic {
    public @Nullable String request(String url) throws IOException {
        try (Response response = this.response(url);
             ResponseBody responseBody = response.body()) {
            return null == responseBody ? null : responseBody.string();
        }
    }

    public @Nullable String request(String url, Headers headers) throws IOException {
        try (Response response = this.response(url, headers);
             ResponseBody responseBody = response.body()) {
            return null == responseBody ? null : responseBody.string();
        }
    }

    public Response response(String url) throws IOException {
        return response(url, null);
    }

    public Response response(String url, Headers headers) throws IOException {
        return method(url, null, headers);
    }

    abstract Response method(String url, RequestBody requestBody, Headers headers) throws IOException;
}
