/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.ch.query;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.tomoncle.config.springboot.ch.ClickHouseProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.List;

/**
 * @author tomoncle
 */
public class JdbcClickHouseQuery {
    private static DataSource ds;

    public JdbcClickHouseQuery(ClickHouseProperties clickHouseProperties) {
        initDatasource(clickHouseProperties);
    }

    private static void initDatasource(ClickHouseProperties clickHouseProperties) {
        ClickHouseProperties.JdbcConfig jdbcConfig = clickHouseProperties.getJdbcConfig();
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(jdbcConfig.getUrl());
        config.setUsername(jdbcConfig.getUsername());
        config.setPassword(jdbcConfig.getPassword());
        config.setDriverClassName(jdbcConfig.getDriverClass());
        config.setAutoCommit(jdbcConfig.isAutoCommit());
        config.setConnectionTimeout(jdbcConfig.getConnectionTimeout());
        config.setIdleTimeout(jdbcConfig.getIdleTimeout());
        config.setMaximumPoolSize(jdbcConfig.getMaxPoolSize());
        ds = new HikariDataSource(config);
    }

    private JSONObject invokeResultSet(ResultSet rs, ResultSetMetaData metaData) throws
            SQLException,
            NoSuchMethodException,
            InvocationTargetException,
            IllegalAccessException {
        int columnCount = metaData.getColumnCount();
        JSONObject json = new JSONObject();
        for (int i = 1; i <= columnCount; i++) {
            String columnName = metaData.getColumnLabel(i);// 列名称
            if (rs.getString(columnName) != null && !rs.getString(columnName).equals("")) {
                // 通过反射获取属性类型并获取值
                String[] classNameArray = metaData.getColumnClassName(i).split("\\.");
                String methodName = "get" + classNameArray[classNameArray.length - 1];
                if ("getInteger".equals(methodName)) {
                    methodName = "getInt";
                }
                Method m = rs.getClass().getDeclaredMethod(methodName, String.class);
                Object invoke = m.invoke(rs, columnName);
                json.put(columnName, invoke);
            }
        }
        return json;
    }

    public JSONArray queryForArray(String sql) {
        JSONArray array = new JSONArray();
        try (Connection connection = ds.getConnection()) {
            try (Statement stmt = connection.createStatement()) {
                try (ResultSet rs = stmt.executeQuery(sql)) {
                    // 获取列数
                    ResultSetMetaData metaData = rs.getMetaData();
                    // 遍历ResultSet中的每条数据
                    while (rs.next()) {
                        array.add(invokeResultSet(rs, metaData));
                    }
                } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return array;
    }


    public JSONObject queryForObject(String sql) {
        JSONObject jsonObject = new JSONObject();
        try (Connection connection = ds.getConnection()) {
            try (Statement stmt = connection.createStatement()) {
                try (ResultSet rs = stmt.executeQuery(sql)) {
                    // 获取列数
                    ResultSetMetaData metaData = rs.getMetaData();
                    // 取出ResultSet中的数据
                    if (!rs.next()) {
                        return jsonObject;
                    }
                    return invokeResultSet(rs, metaData);
                } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }


    /**
     * create / drop / alter
     *
     * @param sqlList sql array
     * @return bool
     */
    public boolean executeQuery(List<String> sqlList) {
        try (Connection connection = ds.getConnection()) {
            try (Statement stmt = connection.createStatement()) {
                for (String sql : sqlList) {
                    stmt.executeQuery(sql);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
