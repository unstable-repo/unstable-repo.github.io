/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.dubbo;


import com.tomoncle.config.springboot.utils.scoket.TcpUtils;
import lombok.Data;
import org.apache.dubbo.config.*;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

@Data
@SuppressWarnings({"WeakerAccess"})
@ConfigurationProperties("spring.boot.config.dubbo")
public class SpringbootConfigDubboProperties {
    private MODE mode = MODE.none;
    private Application application = new Application();
    private Consumer consumer = new Consumer();
    private Registry registry = new Registry();
    private Module module = new Module();
    private Monitor monitor = new Monitor();
    private Protocol protocol = new Protocol();
    private Provider provider = new Provider();

    private String defaultAppName() {
        try {
            return "application-" + String.valueOf(InetAddress.getLocalHost()).split("/")[1] + "-" + new Random().nextInt(1000);
        } catch (UnknownHostException | IndexOutOfBoundsException e) {
            return "application" + "-" + new Random().nextInt(1000);
        }
    }

    public enum MODE {
        none,
        consumer,
        provider
    }

    public class Consumer extends ConsumerConfig {
        public Consumer() {
            super.setCheck(false);  // 启动时检查提供者是否存在，true报错，false忽略
            super.setTimeout(3000);
            super.setLoadbalance("roundrobin");
        }
    }

    public class Registry extends RegistryConfig {
        public Registry() {
            //  http://dubbo.apache.org/zh-cn/docs/user/references/registry/zookeeper.html
            super.setAddress("zookeeper://127.0.0.1:2181"); // 默认注册地址
            super.setClient("curator"); // 默认客户端
        }
    }

    /**
     * QOS 配置:
     * spring.boot.config.dubbo.application.parameters.qos.port=23456
     * or:
     * spring.boot.config.dubbo.application.qos-port=23456
     *
     * @see org.apache.dubbo.common.constants.QosConstants
     */
    public class Application extends ApplicationConfig {
        public Application() {
            super(defaultAppName());
            super.setQosPort(TcpUtils.getFreePort()); // 使用随机端口，覆盖默认的22222端口，单机多个应用不会冲突
        }
    }

    public class Module extends ModuleConfig {
    }

    public class Monitor extends MonitorConfig {
    }

    public class Provider extends ProviderConfig {
        private Provider() {
            super.setTimeout(3000);
            super.setLoadbalance("roundrobin");
        }
    }

    public class Protocol extends ProtocolConfig {
        public Protocol() {
            super.setPort(-1); // 自动注册端口
            super.setName("dubbo"); // 默认使用dubbo协议
        }
    }
}
