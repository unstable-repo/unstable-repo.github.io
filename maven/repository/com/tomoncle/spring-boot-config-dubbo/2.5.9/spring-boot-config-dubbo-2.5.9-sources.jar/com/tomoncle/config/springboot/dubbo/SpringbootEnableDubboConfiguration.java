/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.dubbo;


import org.apache.dubbo.config.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by liyuanjun on 18-9-7.
 *
 * @see org.apache.dubbo.config
 * @see org.apache.dubbo.config.spring.context.annotation.DubboConfigConfiguration
 * 使用 @EnableDubbo 替换 @DubboComponentScan(basePackages = "com.tomoncle.dubbo.samples.provider.impl")
 * <p>
 * 2.7.7版本的dubbo 与springboot 整合时要在应用端application.properties文件配置：spring.main.allow-bean-definition-overriding=true
 * 否则会导致注册失败
 */
@Configuration
@EnableConfigurationProperties(SpringbootConfigDubboProperties.class)
public class SpringbootEnableDubboConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(SpringbootEnableDubboConfiguration.class);

    private final SpringbootConfigDubboProperties dubboProperties;

    public SpringbootEnableDubboConfiguration(SpringbootConfigDubboProperties dubboProperties) {
        this.dubboProperties = dubboProperties;
        logger.info("Initializing dubbo for springboot config. checked mode is [{}]", dubboProperties.getMode());
    }

    /**
     * 应用配置，必选，必须提供name
     *
     * @return ApplicationConfig
     */
    @Bean
    @ConditionalOnMissingBean(ApplicationConfig.class)
    public ApplicationConfig applicationConfig() {
        logger.debug("Initializing Dubbo ApplicationConfig.");
        return dubboProperties.getApplication();
    }

    /**
     * 协议配置，用于配置提供服务的协议信息，协议由提供方指定，消费方被动接受。
     *
     * @return ProtocolConfig
     */
    @Bean
    @ConditionalOnMissingBean(ProtocolConfig.class)
    public ProtocolConfig protocolConfig() {
        logger.debug("Initializing Dubbo ProtocolConfig.");
        return dubboProperties.getProtocol();
    }

    /**
     * 消费方缺省配置，当ReferenceConfig某属性没有配置时，采用此缺省值，可选。
     *
     * @return ConsumerConfig
     */
    @Bean
    @ConditionalOnMissingBean(ConsumerConfig.class)
    @ConditionalOnProperty(value = {"spring.boot.config.dubbo.mode"}, havingValue = "consumer")
    public ConsumerConfig consumerConfig() {
        logger.debug("Initializing Dubbo ConsumerConfig.");
        return dubboProperties.getConsumer();
    }

    /**
     * 提供方的缺省值，当ProtocolConfig和ServiceConfig某属性没有配置时，采用此缺省值，可选。
     *
     * @return ProviderConfig
     */
    @Bean
    @ConditionalOnMissingBean(ProviderConfig.class)
    @ConditionalOnProperty(value = {"spring.boot.config.dubbo.mode"}, havingValue = "provider")
    public ProviderConfig providerConfig() {
        logger.debug("Initializing Dubbo ProviderConfig.");
        return dubboProperties.getProvider();
    }

    /**
     * 注册中心配置，用于配置连接注册中心相关信息, 必选
     *
     * @return RegistryConfig
     */
    @Bean
    @ConditionalOnMissingBean(RegistryConfig.class)
    public RegistryConfig registryConfig() {
        logger.debug("Initializing Dubbo RegistryConfig.");
        return dubboProperties.getRegistry();
    }

    @Bean
    @ConditionalOnMissingBean(ModuleConfig.class)
    @ConditionalOnProperty(value = {"spring.boot.config.dubbo.module.name"})
    public ModuleConfig moduleConfig() {
        logger.debug("Initializing Dubbo ModuleConfig.");
        return dubboProperties.getModule();
    }

    /**
     * 监控中心配置，用于配置连接监控中心相关信息，可选
     *
     * @return MonitorConfig
     */
    @Bean
    @ConditionalOnMissingBean(MonitorConfig.class)
    @ConditionalOnProperty(value = {"spring.boot.config.dubbo.monitor.address"})
    public MonitorConfig monitorConfig() {
        logger.debug("Initializing Dubbo MonitorConfig.");
        return dubboProperties.getMonitor();
    }
}
