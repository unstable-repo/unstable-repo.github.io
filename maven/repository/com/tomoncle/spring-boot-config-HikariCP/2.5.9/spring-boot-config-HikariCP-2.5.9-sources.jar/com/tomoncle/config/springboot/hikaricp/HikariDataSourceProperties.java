/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.hikaricp;

import com.tomoncle.config.springboot.constant.SpringBootConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.io.Serializable;

/**
 * HikariCP properties
 * Created by liyuanjun on 18-5-25.
 */
@ConfigurationProperties(prefix = SpringBootConfig.CONFIG_PREFIX + ".hikaricp")
public class HikariDataSourceProperties implements Serializable {
    private static final long serialVersionUID = 0L;

    // jdbc url
    private String url;

    // connection username
    private String username;

    // connection password
    private String password;

    // 连接只读数据库时配置为true， 保证安全
    private boolean readOnly = false;

    // 自动提交
    private boolean autoCommit = true;

    // 连接驱动
    private String driverClassName = "com.mysql.jdbc.Driver";

    /**
     * 控制连接池空闲连接的最小数量，
     * 当连接池空闲连接少于minimumIdle，而且总共连接数不大于maximumPoolSize时，
     * HikariCP会尽力补充新的连接。
     * <p>
     * 为了性能考虑，不建议设置此值，
     * 而是让HikariCP把连接池当做固定大小的处理，
     * 默认minimumIdle与maximumPoolSize一样。
     * <p>
     * 当minIdle<0或者minIdle>maxPoolSize,则被重置为maxPoolSize，该值默认为10。
     */
    private Integer minimumIdle = -1;

    /**
     * 一个连接idle状态的最大时长（毫秒），超时则被释放（retired
     * 默认是600000毫秒，即10分钟。
     * 如果idleTimeout+1秒>maxLifetime 且 maxLifetime>0，则会被重置为0；
     * 如果idleTimeout!=0且小于10秒，则会被重置为10秒。
     * 如果idleTimeout=0则表示空闲的连接在连接池中永远不被移除。
     * <p>
     * 只有当minimumIdle小于maximumPoolSize时，这个参数才生效，
     * 当空闲连接数超过minimumIdle，而且空闲时间超过idleTimeout，则会被移除。
     */
    private Integer idleTimeout = 30000;

    /**
     * 连接池中允许的最大连接数。
     * 缺省值：10；推荐的公式：((core_count * 2) + effective_spindle_count)
     */
    private Integer maximumPoolSize = 15;

    /**
     * 一个连接的生命时长（毫秒），超时而且没被使用则被释放（retired），
     * 缺省:30分钟，建议设置比数据库超时时长少30秒，
     * 参考MySQL wait_timeout参数（show variables like '%timeout%';）
     */
    private Integer maxLifetime = 1800000;

    /**
     * 等待连接池分配连接的最大时长（毫秒），超过这个时长还没可用的连接则发生SQLException，缺省:30秒
     */
    private Integer connectionTimeout = 30000;

    /**
     * 测试连接SQL
     */
    private String connectionTestQuery = "SELECT 1";


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    public boolean isAutoCommit() {
        return autoCommit;
    }

    public void setAutoCommit(boolean autoCommit) {
        this.autoCommit = autoCommit;
    }

    public String getDriverClassName() {
        return driverClassName;
    }

    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    public Integer getMinimumIdle() {
        return minimumIdle;
    }

    public void setMinimumIdle(Integer minimumIdle) {
        this.minimumIdle = minimumIdle;
    }

    public Integer getIdleTimeout() {
        return idleTimeout;
    }

    public void setIdleTimeout(Integer idleTimeout) {
        this.idleTimeout = idleTimeout;
    }

    public Integer getMaximumPoolSize() {
        return maximumPoolSize;
    }

    public void setMaximumPoolSize(Integer maximumPoolSize) {
        this.maximumPoolSize = maximumPoolSize;
    }

    public Integer getMaxLifetime() {
        return maxLifetime;
    }

    public void setMaxLifetime(Integer maxLifetime) {
        this.maxLifetime = maxLifetime;
    }

    public Integer getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(Integer connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public String getConnectionTestQuery() {
        return connectionTestQuery;
    }

    public void setConnectionTestQuery(String connectionTestQuery) {
        this.connectionTestQuery = connectionTestQuery;
    }
}
