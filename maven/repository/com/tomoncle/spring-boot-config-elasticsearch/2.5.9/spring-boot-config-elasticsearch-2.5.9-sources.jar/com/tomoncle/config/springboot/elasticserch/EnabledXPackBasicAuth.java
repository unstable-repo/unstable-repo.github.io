/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.elasticserch;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.xpack.client.PreBuiltXPackTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 添加 x-pack basic auth 认证.
 *
 * @author tomoncle
 */
@Deprecated
@Configuration
@EnableConfigurationProperties({ElasticProperties.class})
public class EnabledXPackBasicAuth {
    private static final Logger logger = LoggerFactory.getLogger(EnabledXPackBasicAuth.class);

    /**
     * 如果同时配置了这两个参数，则初始化改bean, 而覆盖默认的TransportClient
     * spring.data.elasticsearch.properties.username=elastic
     * spring.data.elasticsearch.properties.password=123456
     *
     * @param properties ElasticsearchProperties
     * @return TransportClient
     */
    @Bean
    @ConditionalOnProperty(value = {
            "spring.boot.config.elasticsearch.username",
            "spring.boot.config.elasticsearch.password"
    })
    public TransportClient transportClient(ElasticProperties properties) {
        logger.info("Initial Elasticsearch X-Pack TransportClient.");
        TransportClient client = null;
        try {
            client = new PreBuiltXPackTransportClient(Settings.builder()
                    .put("cluster.name", properties.getClusterName())
                    .put("xpack.security.user", String.format("%s:%s", properties.getUsername(), properties.getPassword()))
                    .build());
            // 多个配置 xxx.xxx.xxx.xxx:9300,xxx.xxx.xxx.xxx:9300,xxx.xxx.xxx.xxx:9300
            for (String node : properties.getClusterNodes().split(",")) {
                String[] address = node.split(":");
                client.addTransportAddress(new TransportAddress(InetAddress.getByName(address[0]), Integer.valueOf(address[1])));
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return client;
    }
}
