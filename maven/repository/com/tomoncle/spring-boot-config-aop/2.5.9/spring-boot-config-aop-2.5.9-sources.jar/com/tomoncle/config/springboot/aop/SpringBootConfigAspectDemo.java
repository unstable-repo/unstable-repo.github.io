/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.aop;///*
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.*;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.EnableAspectJAutoProxy;
//import org.springframework.core.annotation.AnnotationUtils;
//import org.springframework.stereotype.Component;
//
//import java.util.Arrays;
//import java.util.Objects;
//
///**
// * 定义切面类
// * enabled config: logging.level.com.tomoncle.config.springboot=debug
// */
//
//@Component //组件扫描
//@Aspect  //标注切面类
//@EnableAspectJAutoProxy //启用自动注入切面，不然切面类不起作用
//public class SpringBootConfigAspectDemo {
//    private static Logger logger = LoggerFactory.getLogger(SpringBootConfigAspect.class);
//
//    /**
//     * // @Pointcut("execution(* com.tomoncle.service..*.*(..))")
//     * // @Pointcut(value = "@annotation(com.tomoncle.config.springboot.annotation.AutoDebug)")
//     * // @Before(value = "pointcut() && @annotation(AutoDebug)")
//     * 定义切入点
//     * Pointcut: 标注切面目标对象 （@annotation 只作用在方法级别）
//     */
//    @Pointcut("@annotation(AutoDebug) || @annotation(SilentError)")
//    void aspectPoint() {
//    }
//
//    /**
//     * 前置通知，在方法执行前执行
//     */
//    @Before(value = "aspectPoint()")
//    public void beforeInterceptor(final JoinPoint joinPoint) {
//        this.debugLog("前置通知");
//        this.debugLog(joinPoint);
//    }
//
//    /**
//     * 后置通知，在方法正常返回结果之后执行
//     *
//     * @param flag 方法返回值
//     */
//    @AfterReturning(value = "aspectPoint()", returning = "flag")
//    public void afterReturningInterceptor(final JoinPoint joinPoint, final Object flag) {
//        this.debugLog("后置通知：返回值[" + flag + "]");
//        this.debugLog(joinPoint);
//    }
//
//
//    /**
//     * 环绕通知，环绕方法执行
//     */
//    @SuppressWarnings(value = "all")
//    @Around(value = "aspectPoint()")
//    public Object aroundInterceptor(final ProceedingJoinPoint joinPoint) throws Throwable {
//        this.debugLog(joinPoint);
//        try {
//            final Object result = joinPoint.proceed();
//            this.debugLog(calledInfo(joinPoint) + "，返回值[" + result + "]");
//            return result;
//        } catch (Throwable throwable) {
//            final MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
//            final AutoDebug autoDebug = AnnotationUtils.findAnnotation(methodSignature.getMethod(), AutoDebug.class);
//            if (null != autoDebug) {
//                // 这个异常输出信息，包含参数，所以更敏感，需要判断开启了AutoDebug
//                this.errorLog(joinPoint, throwable);
//            }
//            // 假如包含使用了静默异常处理，则返回空
//            final SilentError silentError = AnnotationUtils.findAnnotation(methodSignature.getMethod(), SilentError.class);
//            if (null != silentError) {
//                if (!Objects.equals("", silentError.value())) {
//                    // 优先使用自定义错误信息
//                    logger.error(calledInfo(joinPoint) + "，异常提示：" + silentError.value());
//                } else if (null == autoDebug) {
//                    // 如果没用开启AutoDebug，并且没用默认错误提示，则输出
//                    logger.error(calledInfo(joinPoint) + "，异常提示：" + throwable);
//                }
//                return null;
//            }
//            throw throwable;
//        }
//    }
//
//    /**
//     * 最终通知，在方法执行后执行,总会执行相当于finally模块
//     */
//    @After(value = "aspectPoint()")
//    public void afterInterceptor(final JoinPoint joinPoint) {
//        this.debugLog(calledInfo(joinPoint) + "，结束执行");
//    }
//
//    /**
//     * 异常通知，在方法抛出异常之后
//     */
//    @AfterThrowing(value = "aspectPoint()", throwing = "e")
//    public void errorInterceptor(final JoinPoint joinPoint, final RuntimeException e) {
//        this.errorLog(joinPoint, e);
//    }
//
//    private String calledInfo(final JoinPoint joinPoint) {
//        return Thread.currentThread().getName() + "：调用"
//                + joinPoint.getTarget().getClass().getSimpleName()
//                + "的" + joinPoint.getSignature().getName()
//                + "方法";
//    }
//
//    private void debugLog(final String message) {
//        logger.debug(message);
//    }
//
//
//    private void debugLog(final JoinPoint joinPoint) {
//        logger.debug(calledInfo(joinPoint) + "，方法入参：" + Arrays.toString(joinPoint.getArgs()));
//    }
//
//    private void errorLog(final JoinPoint joinPoint, final Throwable throwable) {
//        logger.error(calledInfo(joinPoint)
//                + "，方法入参：" + Arrays.toString(joinPoint.getArgs())
//                + "，触发异常：" + throwable);
//    }
//
//
//}
