/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.mail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.Properties;

/**
 * @Time : 2017/12/19 5:06
 * @Author : TOM.LEE
 * @File : SmtpMailSender.java
 */
@Component
@EnableConfigurationProperties({MailConfigurationProperties.class})
public class SmtpMailSender {
    private static final Logger logger = LoggerFactory.getLogger(SmtpMailSender.class);
    //根据配置创建会话对象, 用于和邮件服务器交互
    private static Session session;
    private final MailConfigurationProperties properties;

    @Autowired
    public SmtpMailSender(MailConfigurationProperties properties) {
        this.properties = properties;
        Properties prop = new Properties();
        prop.setProperty("mail.transport.protocol", "smtp"); // 使用的协议（JavaMail规范要求）
        prop.setProperty("mail.smtp.host", properties.getHost()); // 发件人的邮箱的 SMTP 服务器地址
        prop.setProperty("mail.smtp.auth", String.valueOf(properties.isAuth())); // 需要请求认证
        prop.setProperty("mail.smtp.port", String.valueOf(properties.getPort()));
        prop.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        prop.setProperty("mail.smtp.socketFactory.fallback", "false");
        prop.setProperty("mail.smtp.socketFactory.port", String.valueOf(properties.getPort()));
        session = Session.getInstance(prop);
        session.setDebug(properties.isDebug()); // 设置为debug模式, 可以查看详细的发送 log
    }

    /**
     * 发送邮件
     *
     * @param receiveMail 收件人
     * @param subject     主题
     * @param content     内容
     */
    public void sendTextMail(String receiveMail, String subject, String content) {
        Transport transport = null;
        try {
            transport = session.getTransport();
            transport.connect(properties.getUsername(), properties.getPassword());
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(properties.getUsername(), properties.getPersonal(), "UTF-8"));
            message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(receiveMail, "", "UTF-8"));
            message.setSubject(subject, "UTF-8");
            message.setContent(content, "text/html;charset=UTF-8");
            message.setSentDate(new Date());
            message.saveChanges();
            transport.sendMessage(message, message.getAllRecipients());
            logger.info("sendTextMail to " + receiveMail + "success!");
        } catch (Exception e) {
            logger.error("sendTextMail to " + receiveMail + "fail!");
            logger.error(e.getMessage());
        } finally {
            if (transport != null && transport.isConnected()) {
                try {
                    transport.close();
                } catch (MessagingException e) {
                    e.printStackTrace();
                }
            }
        }


    }

}