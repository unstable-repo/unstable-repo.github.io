/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.handler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 实现ErrorController接口是重写BaseErrorController的error实现.
 * 实现HandlerExceptionResolver接口是重写异常解析处理函数
 * Created by tom.lee on 2017/7/16.
 */
@Controller
@RequestMapping("/error")
public class DefaultErrorHandler implements ErrorController, HandlerExceptionResolver {

    private static final Log logger = LogFactory.getLog(DefaultErrorHandler.class);

    /**
     * 重写BaseErrorController的error实现
     *
     * @return 处理异常的连接地址
     */
    public String getErrorPath() {
        return "/error";
    }


    /**
     * 具体处理/error接口的异常方法
     *
     * @param request  HTTP请求对象
     * @param response Http相应对象
     * @param o        异常类
     * @param e        异常信息
     * @return 返回到系统定义的异常ModelAndView
     */
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) {
        return null;
    }

    /**
     * 该方法对应getErrorPath方法对应的转发地址 return "/error"，这样就重写的默认的/error地址
     *
     * @param httpServletRequest HTTP请求对象
     * @return 返回到系统统一处理的resolveException
     */
    // 相同的地址，添加该属性(produces = "text/html")，浏览器请求时，根据头部信息，转到该方法
//    @RequestMapping(produces = "text/html")
//    public ModelAndView errorHtml(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
//        return resolveException(httpServletRequest, httpServletResponse, o, e);
//    }

    // 浏览器请求时，根据头部信息，转到该方法
    // curl -i -X GET -H "Accept:text/html"  localhost:8080/app/nil/notFound
    @RequestMapping(produces = "text/html")
    @ResponseBody
    public String errorHtml(HttpServletRequest httpServletRequest) {
        return HttpTools.errorHtml(httpServletRequest);
    }

    // 接口请求，转到该方法
    @RequestMapping
    @ResponseBody
    public ResponseEntity<Map<String, Object>> error(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) {
        Map<String, Object> body = new HashMap<>();
        HttpStatus status = HttpTools.getStatus(request);
        body.put("status", status.value());
        body.put("timestamp", new Date());
        body.put("data", null);
        body.put("path", HttpTools.getRequestPath(request));
        body.put("method", request.getMethod());
        body.put("message", status.getReasonPhrase());
        logger.error(String.format("\033[31;mDefaultErrorHandler error: path -> %s; message -> %s\033[0m", body.get("path"), body.get("message")));
        return new ResponseEntity<>(body, status);
    }

}
